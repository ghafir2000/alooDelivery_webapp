@extends('layouts.back-end.app')

@section('title', translate('driver_tracking'))

@push('css_or_js')
    <style>
        #map {
            height: 600px;
            width: 100%;
            border-radius: 8px;
        }
    </style>
@endpush

@section('content')
<div class="content container-fluid main-card {{Session::get('direction')}}">
    <div class="mb-4">
        <h2 class="h1 mb-0 text-capitalize d-flex align-items-center gap-2">
            <!-- الصورة لسه محذوفة عشان ما تسببش مشاكل -->
            {{ translate('driver_tracking') }}
        </h2>
    </div>

    <div class="card">
        <div class="card-body">
            <div id="map"></div>
        </div>
    </div>
</div>
@endsection

@push('script')
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAGxomOTVq8QJpe_GUUWv5mOuuMf_IJyf4&libraries=places"></script>
    <script>
        let map;

        function initMap() {
            map = new google.maps.Map(document.getElementById('map'), {
                center: { lat: 25.276987, lng: 55.296249 }, 
                zoom: 12,
            });
        }

        window.onload = initMap;
    </script>
@endpush
